package kalah;
import com.qualitascorpus.testsupport.MockIO;
public class MainRunner {
	public static void main(String[] args) {
		new Kalah().play(new MockIO());
	}
}
