package kalah.game;

/**
 * Stone Object for the game.
 */
public class Stone {
    /** Constructor. */
    public Stone() {
    }
}
