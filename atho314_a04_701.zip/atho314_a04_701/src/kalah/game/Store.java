package kalah.game;

/**
 * The object of each player's score (number of stones collected).
 */
public class Store extends Pit{

    /**
     * Store constructor.
     */
    public Store() {
        super();
    }
}
