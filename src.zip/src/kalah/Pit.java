package kalah;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Object of a pit on the board.
 */
public class Pit {

    private final ArrayList<Stone> stones;

    /**
     * Add initial stones to the pit for start of the game.
     * @param initStones how many stones put initially in the pit.
     */
    public Pit(int initStones) {
        this.stones = new ArrayList<>();
        for (int i = 0; i < initStones; i++) {
            Stone stone = new Stone();
            this.stones.add(stone);
        }
    }

    /**
     * Gets size of the pit.
     * @return the number of stones.
     */
    public Integer size() {
        return stones.size();
    }

    /**
     * Increment the number of stones in a pit by one.
     * @param stone the stone to add.
     */
    protected void addStone(Stone stone) {
        stones.add(stone);
    }

    /**
     * Removes all stones from a pit and puts it in a stack.
     * @return all the current stones in a LinkedList.
     */
    protected LinkedList<Stone> removeAllStones() {
        LinkedList<Stone> takenStones = new LinkedList<>(stones);
        stones.clear();
        return takenStones;
    }

    /**
     * Will see if there there are no stones left in the pit.
     * @return True if there are no stones. False if >0 stones.
     */
    public Boolean isEmpty() {
        return stones.isEmpty();
    }
}



