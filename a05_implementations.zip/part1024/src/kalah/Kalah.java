package kalah;
import com.qualitascorpus.testsupport.IO;
public class Kalah {
	private KalahBoard board;
	private BoardPrinter boardPrinter;
	private Player player1;
	private Player player2;
	public Kalah () {
		board = new KalahBoard();
		setupGame();
	}
	public Kalah(int house, int seed) {
		board = new KalahBoard(house,seed);
		setupGame();
	}
	private void setupGame () {
		boardPrinter = new KalahBoardPrinter();
		player1 = new HumanPlayer("P1");
		player2 = new HumanPlayer("P2");
	}
	public void play (IO io) {
		//start the game show the board state.	
		boardPrinter.print(board,io,player1.getName(),player2.getName());
		//keep tracking of which player is the current player
		boolean isFirstPlayerTurn = true;
		Player currentPlayer = player1;
		int value = 0;
		while(!board.isEmptyHouse(isFirstPlayerTurn)) {
			value = currentPlayer.getChoice(io);
			if (value == -1) {
				break;
			}
			SownResult result = sownOnly(board,isFirstPlayerTurn,value);
			//handle the result from sowning, if the result is null it means the house was empty
			if (result == null) {
				io.println("House is empty. Move again.");
			} else  {
				boolean nextTurn = checkSownResult(result,board,isFirstPlayerTurn);
				if (nextTurn) {
					isFirstPlayerTurn = !isFirstPlayerTurn;
					if (currentPlayer.equals(player1)) {
						currentPlayer = player2;
					} else {
						currentPlayer = player1;
					}
				}
			}
			boardPrinter.print(board,io,player1.getName(),player2.getName());
		}
		io.println("Game over");
		boardPrinter.print(board,io,player1.getName(),player2.getName());
		if (value != -1) boardPrinter.printPlayerScore(board, io);
	}
	private boolean checkSownResult(SownResult result, KalahBoard board, boolean isFirstPlayerTurn) {
		int[] firstArray = board.getFirstPlayerHouses();
		int[] secondArray = board.getSecondPlayerHouses();
		int numberOfHouse = board.getNumberOfHouse();
		if (!isFirstPlayerTurn) {
			int[] tempArray = firstArray;
			firstArray	= secondArray;
			secondArray = tempArray;
		}
		if (result.getHouseType() == SownResult.PLAYER_HOUSE) {
			int currentIndex = result.getLastSown();
			if (firstArray[currentIndex] == 1 && secondArray[numberOfHouse-currentIndex-1] != 0) {
				//capture seed from opposite house
				if (isFirstPlayerTurn) {
					board.addFirstPlayerStorage(firstArray[currentIndex] + secondArray[numberOfHouse-currentIndex-1]);
				} else {
					board.addSecondPlayerStorage(firstArray[currentIndex] + secondArray[numberOfHouse-currentIndex-1]);
				}
				firstArray[currentIndex] = 0;
				secondArray[numberOfHouse-currentIndex-1] = 0;
			}
			return true;
		} else if (result.getHouseType() == SownResult.PLAYER_STORAGE) {
			//get extra turn if last sown is on the player storage
			return false;
		} else {
			//next turn since it landed on opponent house
			return true;
		}
	}
	private SownResult sownOnly(KalahBoard board, boolean isFirstPlayerTurn, int houseNumber){
		int[] firstArray = board.getFirstPlayerHouses();
		int[] secondArray = board.getSecondPlayerHouses();
		int numberOfHouse = board.getNumberOfHouse();
		if (!isFirstPlayerTurn) {
			int[] tempArray = firstArray;
			firstArray	= secondArray;
			secondArray = tempArray;
		}
		//check if house is empty
		if (firstArray[houseNumber-1] == 0) {
			return null;
		}
		int count = firstArray[houseNumber-1];
		int currentIndex = houseNumber;
		firstArray[houseNumber-1] = 0;
		while (count != 0) {
			//the player house
			while(currentIndex < numberOfHouse && count != 0) {
				firstArray[currentIndex] += 1;
				count--;
				currentIndex++;
			}
			if (count == 0) {
				return new SownResult(SownResult.PLAYER_HOUSE,currentIndex-1);
			};
			currentIndex = 0;
			//the player storage
			if (isFirstPlayerTurn) {
				board.addFirstPlayerStorage(1);
			} else {
				board.addSecondPlayerStorage(1);
			}
			count--;
			//last seed sown at the player storage, extra turn
			if (count == 0) return new SownResult(SownResult.PLAYER_STORAGE,-1);
			//opponent houses
			while(currentIndex < numberOfHouse && count != 0) {
				secondArray[currentIndex] += 1;
				count--;
				currentIndex++;
			}
			currentIndex = 0;
		}
		//last seed sown on opponent house, no extra turn;
		return new SownResult(SownResult.OPPONENT_HOUSE,currentIndex-1);
	}
}
