package kalah.player;

import kalah.game.*;

/**
 * HumanPlayer Object that has each player's pit and store objects.
 */
public class HumanPlayer extends Player {

    /**
     * Constructor with number of houses for a player and the number of stones for each pit.
     * @param name The player's name.
     * @param initStones The number stones for each pit.
     * @param initPits The number of houses for the player.
     */
    public HumanPlayer(String name, int initStones, Integer initPits) {
        super(name, initStones, initPits);

        for (int i = 0; i < initPits; i++) {
            House house = new House(initStones);
            this.houses.add(house);
        }
    }
}

