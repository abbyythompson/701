package kalah;

import java.util.LinkedList;

/**
 * The game engine of kalah. For processing moves and the players.
 */
public class Game {
    private static final String P1 = "P1";
    private static final String P2 = "P2";
    private static final Integer INIT_PITS = 6;
    private static final Integer INIT_STONES = 4;

    private final Player p1;
    private final Player p2;
    private Status status;
    private Move move;

    /**
     * The Game Engine Constructor with the mode.
     */
    public Game() {
        this.p1 = new Player(P1, INIT_STONES, INIT_PITS);
        this.p2 = new Player(P2, INIT_STONES, INIT_PITS);
        this.status = Status.INIT;
    }

    /**
     * Getter of the current move.
     * @return the move.
     */
    public Move getMove() {
        return move;
    }

    /**
     * Getter of game status.
     * @return the status.
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Sets the game status.
     * @return the game status.
     */
    public void setStatus(Status statusSet) {
        status = statusSet;
    }

    /**
     * Player 1 getter.
     * @return first player.
     */
    public Player getPlayer1() {
        return p1;
    }

    /**
     * Player 2 getter.
     * @return second player.
     */
    public Player getPlayer2() {
        return p2;
    }

    /**
     * Starts the game.
     */
    public void start() {
        status = Status.PLAYER1_TURN;
    }

    /**
     * Carries out the move indicate by the pitIndex.
     * @param pitIndex the index of the pit.
     */
    public void move(Integer pitIndex) {

        processMove(pitIndex);

        switch (move) {
            case ILLEGAL: {
                break;
            }
            case CONTINUE:
            case STEAL: {
                changePlayerTurn();
                break;
            }
            case ANOTHER_TURN: {
                break;
            }
        }
    }

    /**
     * Moving all the stones from each pit and defining the move.
     * @param pitIndex the index that a player chose to move from.
     * @return the move.
     */
    private void processMove(Integer pitIndex) {
        if (!validMove(pitIndex)) {
            move = Move.ILLEGAL;
            return;
        }

        Player currentPlayer = movingPlayer();
        Player opponentPlayer = opponentPlayer(currentPlayer);

        Pit pit = currentPlayer.getPit(pitIndex);
        LinkedList<Stone> stones = pit.removeAllStones();
        move = Move.CONTINUE;
        Boolean isOpponentArea = false;

        while (!stones.isEmpty()) {

            Stone stone = stones.remove();
            pitIndex++;
            move = Move.CONTINUE;
            pit = currentPlayer.getPit(pitIndex);

            if (pit != null) {
                Boolean opponentPitEmpty = opponentPlayer.getPit(5 - pitIndex).isEmpty();

                if (!isOpponentArea && pit.isEmpty() && !opponentPitEmpty) {
                    move = Move.STEAL;
                }
                pit.addStone(stone);

            } else {

                if (!isOpponentArea) {
                    House housePit = currentPlayer.getHouse();
                    housePit.addStone(stone);
                    move = Move.ANOTHER_TURN;
                } else {
                    //add the stone back to play at opponent's area in next iteration.
                    stones.add(stone);
                }
                currentPlayer = opponentPlayer(currentPlayer);
                isOpponentArea = !isOpponentArea;
                pitIndex = -1;
            }
        }
        if (move == Move.STEAL) {
            steal(pitIndex);
        }
    }

    /**
     * Find out if a selected pit is empty or not.
     * @param pitIndex the index that a player chose to move from.
     * @return true when pit is not empty. False when empty.
     */
    private Boolean validMove(Integer pitIndex) {
        if (movingPlayer().getPit(pitIndex) != null) {
            return !movingPlayer().getPit(pitIndex).isEmpty();
        }
        return false;
    }

    /**
     * When the player makes a steal, this carries it out.
     * @param pitIndex the index that a player chose to move from.
     */
    private void steal(Integer pitIndex) {
        Player currentPlayer = movingPlayer();
        House currentPlayerHouse = currentPlayer.getHouse();
        LinkedList<Stone> stones = currentPlayer.getPit(pitIndex).removeAllStones();
        for (Stone stone : stones) {
            currentPlayerHouse.addStone(stone);
        }
        Player opponentPlayer = opponentPlayer(currentPlayer);
        stones = opponentPlayer.getPit((INIT_PITS - 1) - pitIndex).removeAllStones();
        for( Stone stone : stones) {
            currentPlayerHouse.addStone(stone);
        }
    }

    /**
     * @return the current player who is moving.
     */
    public Player movingPlayer() {
        switch (status) {
            case PLAYER1_TURN: {
                return p1;
            }
            case PLAYER2_TURN: {
                return p2;
            }
        }
        return null;
    }

    /**
     * @return the other player than that entered.
     */
    private Player opponentPlayer(Player player) {
        if (player.getName().equals(P1)) {
            return p2;
        }
        return p1;
    }

    /**
     * Change the Status of the game to who's turn it is.
     */
    private void changePlayerTurn() {
        switch (status) {
            case PLAYER1_TURN: {
                status = Status.PLAYER2_TURN;
                break;
            }
            case PLAYER2_TURN: {
                status = Status.PLAYER1_TURN;
                break;
            }
        }
    }

    /**
     * Finds out whether there are stones in the board for the next player's turn.
     * @return True is all the other pits are empty. False if some of them are full.
     */
    public boolean gameFinished(Player player) {
        if (this.getStatus() == Status.PLAYER1_TURN) {
            return !p1.hasStones();
        } else {
            return !p2.hasStones();
        }
    }

    /**
     * Gets the player that won.
     * @return the player that won. Null if it's a tie.
     */
    public Player getWinner() {
        if (p1.getHouse().size() > p2.getHouse().size()) {
            return p1;
        }
        if (p2.getHouse().size() > p1.getHouse().size()) {
            return p2;
        }
        return null;
    }

    /**
     * Check if the board is empty before counting up the last remaining stones to count towards the end score.
     */
    public void finishMove() {
        if (!p1.getPits().isEmpty()) {
            getEndScore(p1);
        }
        if (!p2.getPits().isEmpty()) {
            getEndScore(p2);
        }
    }

    /**
     * Getting the last stones from the board for the score.
     */
    public void getEndScore(Player player){
        if (!player.getPits().isEmpty()) {
            for (Pit pit:player.getPits()) {
                LinkedList<Stone> stones = pit.removeAllStones();
                while (!stones.isEmpty()){
                    Stone stone = stones.remove();
                    player.getHouse().addStone(stone);
                }
            }
        }
    }


}