package kalah.stucture;
public class Store extends Container{
	public Store(Group group) {
		this(0, group);
	}
	public Store(int seedNum, Group group) {
		super(seedNum, group);
	}
}
