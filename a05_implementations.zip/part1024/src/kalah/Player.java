package kalah;
import com.qualitascorpus.testsupport.IO;
public abstract class Player {
	protected String name;
	public Player(String name) {
		this.name = name;
	}
	public abstract int getChoice(IO io);
	public String getName() {
		return name;
	}
}
