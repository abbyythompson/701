package kalah;

import java.util.ArrayList;

/**
 * The object of each player's score (number of stones collected).
 */
public class House {

    private final ArrayList<Stone> stones;

    /**
     * House constructor.
     */
    public House() {
        this.stones = new ArrayList<>();
    }

    /**
     * Returns a player's score.
     * @return the size of the house.
     */
    public int size() {
        return stones.size();
    }

    /**
     * Increment the score by one.
     * @param stone to add to the house.
     */
    protected void addStone(Stone stone) {
        stones.add(stone);
    }

}