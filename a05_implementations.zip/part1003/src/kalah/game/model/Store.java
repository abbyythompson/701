package kalah.game.model;
import kalah.game.model.Pit;
import kalah.game.model.Player;
public class Store implements Pit {
  private Player player;
  private int numSeeds;
  public Store(Player player, int numSeeds) {
    this.player = player;
    this.numSeeds = numSeeds;
  }
  @Override
  public Player getPlayer() {
    return player;
  }
  @Override
  public int getSeeds() {
    return numSeeds;
  }
  @Override
  public void setSeeds(int numSeeds) {
    this.numSeeds = numSeeds;
  }
}