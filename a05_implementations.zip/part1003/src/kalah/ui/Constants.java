package kalah.ui;
public class Constants {
  public static final String GAME_OVER = "Game over";
  public static final String HOUSE_IS_EMPTY = "House is empty. Move again.";
  public static final String PLAYER_1_PROMPT = "Player P1's turn - Specify house number or 'q' to quit: ";
  public static final String PLAYER_2_PROMPT = "Player P2's turn - Specify house number or 'q' to quit: ";
  public static final String PLAYER_1_SCORE = "player 1";
  public static final String PLAYER_2_SCORE = "player 2";
  public static final String PLAYER_1_WINS = "Player 1 wins!";
  public static final String PLAYER_2_WINS = "Player 2 wins!";
  public static final String TIE = "A tie!";
}
