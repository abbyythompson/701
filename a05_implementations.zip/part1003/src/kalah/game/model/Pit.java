package kalah.game.model;
import kalah.game.model.Player;
public interface Pit {
  Player getPlayer();
  int getSeeds();
  void setSeeds(int numSeeds);
}
