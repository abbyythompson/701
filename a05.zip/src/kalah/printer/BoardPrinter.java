package kalah.printer;

import kalah.game.*;
import kalah.player.*;

import com.qualitascorpus.testsupport.IO;
import kalah.player.HumanPlayer;

/**
 * Created by abbythompson on 9/06/17.
 */
public class BoardPrinter implements IBoardPrinter{
    private IO io;
    private IGame game;
    private Player p1;
    private Player p2;

    public BoardPrinter(IO io, Game game){
        this.io = io;
        this.game = game;

        p1 = game.getPlayer1();
        p2 = game.getPlayer2();
    }

    /**
     * Print the current state of the board.
     */
    public void printBoard(){
        String line = "+----+-------+-------+-------+-------+-------+-------+----+";
        String midLine = "|    |-------+-------+-------+-------+-------+-------|    |";

        // Start of printing the board
        io.println(line);
        io.print("| P2 | ");

        for(int i = 6; i > 0; i--){
            printPits(p2, i);
        }

        printHouse(p1, true);
        io.println(midLine);
        io.print("| ");
        printHouse(p2, false);

        for(int i = 1; i < 7; i++){
            printPits(p1, i);
        }

        io.println("P1 |");
        io.println(line);
    }

    /**
     * Print the specific house for a player.
     * @param player player to get their specific house.
     * @param newline whether it needs a new line or not.
     */
    private void printHouse(Player player, Boolean newline){
        if (player.getStore().size() < 10) {
            io.print(" ");
        }
        if (newline) {
            io.println(player.getStore().size() + " |");
        } else {
            io.print(player.getStore().size() + " | ");

        }
    }

    /**
     * Print the specific pit for a player.
     * @param player player to get their pits.
     * @param i the current iteration in the loop.
     */
    private void printPits(Player player, int i){
        if (9 < player.getHouses().get(i-1).size()) {
            io.print(i + "[");
        } else {
            io.print(i + "[ ");
        }
        io.print(String.valueOf(player.getHouses().get(i-1).size()));
        io.print("] | ");
    }

    /**
     * Print out the game over, last board and tally up the scores.
     */
    public void printEndGame(){
        io.println(Constants.GAME_OVER);
        printBoard();
    }

    /**
     * Print the score and who won/tied.
     */
    public void printWinner() {
        Player winner = game.getWinner();

        io.println("\t" + Constants.P1_SCORE + ":" + p1.getStore().size());
        io.println("\t" + Constants.P2_SCORE + ":" + p2.getStore().size());

        if (winner != null){
            if (winner == p1) {
                io.println(Constants.P1_WINNER);
            } else {
                io.println(Constants.P2_WINNER);
            }
        } else {
            io.println(Constants.GAME_TIE);
        }
    }
}
