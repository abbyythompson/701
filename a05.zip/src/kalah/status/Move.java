package kalah.status;

/**
 * What move the player performs.
 */
public enum Move {

    /** Invalid Move. */
    ILLEGAL,
    /** No invalid moves have been performed. */
    CONTINUE,
    /** A player performs a steal. */
    STEAL,
    /** The player has another turn. */
    ANOTHER_TURN;

    Move() {
    }
}
