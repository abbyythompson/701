package kalah;
import com.qualitascorpus.testsupport.IO;
import com.qualitascorpus.testsupport.MockIO;
import kalah.game.Game;
import kalah.game.IGame;
import kalah.ui.Display;
import kalah.ui.IDisplay;
public class Kalah {
  private static final int HOUSES = 6;
  private static final int SEEDS = 4;
  private static final boolean ANTICLOCKWISE = true;
  private static final boolean EMPTY_CAPTURE = false;
  public static void main(String[] args) {
    new Kalah().play(new MockIO());
  }
  public void play(IO io) {
    IGame game = new Game(HOUSES, SEEDS, ANTICLOCKWISE, EMPTY_CAPTURE);
    IDisplay display = new Display(io, game);
    display.showBoard();
    while (true) {
      int input = display.prompt();
      if (input == -1) {
        display.showQuit();
        return;
      } else {
        if (!game.canSelectHouse(input)) {
          display.showEmpty();
          continue;
        }
        game.takeTurn(input);
        display.showBoard();
        if (game.gameEnded()) {
          display.showScore();
          return;
        }
      }
    }
  }
}
