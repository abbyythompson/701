package kalah;
import com.qualitascorpus.testsupport.IO;
public class KalahBoardPrinter implements BoardPrinter {
	public void print(KalahBoard board, IO io, String player1Name, String player2Name) {
		//maybe can extract to printer class, for now just do it here
		StringBuilder line1 =  new StringBuilder();
		StringBuilder line2 =  new StringBuilder();
		StringBuilder line3 =  new StringBuilder();
		StringBuilder line4 =  new StringBuilder();
		StringBuilder line5 =  new StringBuilder();
		int numberOfHouse = board.getNumberOfHouse();
		int[] secondPlayerHouses = board.getSecondPlayerHouses();
		int[] firstPlayerHouses = board.getFirstPlayerHouses();
		//print second player storage;
		line1.append("+----");
		line2.append("| "+ player2Name + " ");
		line3.append("|    ");
		line4.append("| " + formatDigit(board.getSecondPlayerStorage()) + " ");
		line5.append("+----");
		//print the houses
		for (int i = 0; i<numberOfHouse; i++) {
			int fIndex = i+1;
			int sIndex = numberOfHouse - i;
			line1.append("+-------");
			line2.append("| " + sIndex + "[" + formatDigit(secondPlayerHouses[numberOfHouse-i-1]) + "] ");
			if (i == 0) {
				line3.append("|-------");
			} else {
				line3.append("+-------");
			}
			line4.append("| " + fIndex + "[" + formatDigit(firstPlayerHouses[i]) + "] ");
			line5.append("+-------");
			//assume single digit table for now
		}
		//print second player storage;
		line1.append("+----+");
		line2.append("| " + formatDigit(board.getFirstPlayerStorage()) + " |");
		line3.append("|    |");
		line4.append("| " + player1Name + " |");
		line5.append("+----+");
		io.println(line1.toString());
		io.println(line2.toString());
		io.println(line3.toString());
		io.println(line4.toString());
		io.println(line5.toString());
	}
	private String formatDigit (int digit) {
		if (digit > 9 ) {
			return String.valueOf(digit);
		} else {
			return " " + digit;
		}
	}
	public void printPlayerScore(KalahBoard board, IO io) {
		int playerOneSum = board.getFirstPlayerStorage();
		int playerTwoSum = board.getSecondPlayerStorage();
		for (int i = 0; i<board.getNumberOfHouse(); i++) {
			playerOneSum += board.getFirstPlayerHouses()[i];
			playerTwoSum += board.getSecondPlayerHouses()[i];
		}
		io.println("\tplayer 1:" + playerOneSum);
		io.println("\tplayer 2:" + playerTwoSum);
		if (playerOneSum == playerTwoSum) {
			io.println("A tie!");
		} else {
			if (playerOneSum > playerTwoSum) {
				io.println("Player 1 wins!");
			} else {
				io.println("Player 2 wins!");
			}
		}
	}
}
