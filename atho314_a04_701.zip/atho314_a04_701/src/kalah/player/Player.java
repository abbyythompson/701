package kalah.player;

import kalah.game.House;
import kalah.game.Store;

import java.util.ArrayList;

/**
 * Abstract class for the Player Object
 */
public abstract class Player {
    protected final String name;
    protected final ArrayList<House> houses;
    protected final Store store;

    Player(String name, int initStones, Integer initPits) {
        this.name = name;
        this.houses = new ArrayList<>();
        this.store = new Store();
    }

    /**
     * Getter for name of player.
     * @return the name of the player.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the player's pit that is asked for by it's index.
     * @param pitIndex index of the pit. 0..initIndex-1.
     * @return the requested pit or null if out of range.
     */
    public House getPit(Integer pitIndex) {
        if (pitIndex < 0 || pitIndex >= houses.size()) {
            return null;
        }
        return houses.get(pitIndex);
    }

    /**
     * Getter for player's store.
     * @return the player's store.
     */
    public Store getStore() {
        return store;
    }

    /**
     * If the player has any stones left.
     * @return true is player has stones. False if not.
     */
    public Boolean hasStones() {
        for (House house : houses) {
            if (house.size() > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Getter of houses in indexed array.
     * @return array of houses.
     */
    public ArrayList<House> getHouses() {
        return houses;
    }
}
