package kalah;
public class KalahBoard {
	public final static  int DEFAULT_SEED = 4;
	public final static  int DEFAULT_HOUSE = 6;
	private int numberOfHouse;
	private int[] firstPlayerHouses;
	private int[] secondPlayerHouses;
	private int firstPlayerStorage;
	private int secondPlayerStorage;
	public KalahBoard(int house, int seeds) {
		setupBoard(house,seeds);
	}
	public KalahBoard() {
		setupBoard(DEFAULT_HOUSE,DEFAULT_SEED);
	}
	private void setupBoard(int house, int seeds) {
		numberOfHouse = house;
		firstPlayerHouses = new int[numberOfHouse];
		secondPlayerHouses = new int[numberOfHouse];
		for (int i = 0; i<numberOfHouse; i++) {
			firstPlayerHouses[i] = seeds;
			secondPlayerHouses[i] = seeds;
		}
		firstPlayerStorage = 0;
		secondPlayerStorage = 0;
	}
	public boolean isEmptyHouse(boolean isFirstPlayerTurn) {
		int[] checkArray = firstPlayerHouses;
		if (!isFirstPlayerTurn) {
			checkArray = secondPlayerHouses;
		}
		for (int i = 0; i<numberOfHouse; i++) {
			if (checkArray[i] != 0) {
				return false;
			}
		}
		return true;
	}
	public int getNumberOfHouse() {
		return numberOfHouse;
	}
	public int[] getFirstPlayerHouses() {
		return firstPlayerHouses;
	}
	public int[] getSecondPlayerHouses() {
		return secondPlayerHouses;
	}
	public int getFirstPlayerStorage() {
		return firstPlayerStorage;
	}
	public int getSecondPlayerStorage() {
		return secondPlayerStorage;
	}
	public void addFirstPlayerStorage(int i) {
		firstPlayerStorage += i;
	}
	public void addSecondPlayerStorage(int i) {
		secondPlayerStorage += i;
	}
}
