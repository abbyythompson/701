package kalah.game.model;
public enum Player {
  PLAYER_1, PLAYER_2
}
