package kalah.ui;
public interface IDisplay {
  int prompt();
  void showBoard();
  void showQuit();
  void showEmpty();
  void showScore();
}
