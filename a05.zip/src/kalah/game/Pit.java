package kalah.game;


import java.util.ArrayList;

/**
 * Abstract class for the House and Store, providing common code.
 */
public abstract class Pit {
    final ArrayList<Stone> stones;
    Pit() {
        this.stones = new ArrayList<>();
    }
    public int size() {
        return stones.size();
    }
    void addStone(Stone stone) {
        stones.add(stone);
    }
}
