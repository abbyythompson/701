package kalah;
import com.qualitascorpus.testsupport.IO;
public interface BoardPrinter {
	public void print(KalahBoard board, IO io, String player1Name, String player2Name);
	public void printPlayerScore(KalahBoard board, IO io);
}
