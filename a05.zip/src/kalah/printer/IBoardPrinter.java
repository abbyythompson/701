package kalah.printer;

/**
 * Created by abbythompson on 9/06/17.
 */
public interface IBoardPrinter {
    void printBoard();
    void printEndGame();
    void printWinner();
}
