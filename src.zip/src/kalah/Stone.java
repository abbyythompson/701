package kalah;

/**
 * Stone Object for the game.
 */
public class Stone {
    /** Constructor. */
    public Stone() {
    }
}