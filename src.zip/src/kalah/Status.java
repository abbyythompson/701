package kalah;

/**
 * Status enum for the game.
 */
public enum Status {

    /** Game has not started yet. */
    INIT,
    /** Player 1's turn. */
    PLAYER1_TURN,
    /** Player 2's turn. */
    PLAYER2_TURN,
    /** Game has finished. */
    FINISHED;

    Status() {
    }
}