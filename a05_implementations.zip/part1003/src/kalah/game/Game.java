package kalah.game;
import kalah.game.model.House;
import kalah.game.model.Pit;
import kalah.game.model.Player;
import kalah.game.model.Store;
import java.util.ArrayList;
public class Game implements IGame {
  private enum Direction {CLOCKWISE, ANTICLOCKWISE};
  private ArrayList<Pit> pits = new ArrayList<>();
  private int numHouses;
  private Direction direction;
  private Player currentPlayer;
  private boolean emptyCapture;
  public Game(int numHouses, int numSeeds, boolean anticlockwise, boolean emptyCapture) {
    this.currentPlayer = Player.PLAYER_1;
    this.direction = anticlockwise ? Direction.ANTICLOCKWISE : Direction.CLOCKWISE;
    this.emptyCapture = emptyCapture;
    this.numHouses = numHouses;
    for (int i = 0; i < numHouses; i++) {
      pits.add(new House(Player.PLAYER_1, numSeeds));
    }
    pits.add(new Store(Player.PLAYER_1, 0));
    for (int j = 0; j < numHouses; j++) {
      pits.add(new House(Player.PLAYER_2, numSeeds));
    }
    pits.add(new Store(Player.PLAYER_2, 0));
  }
  @Override
  public int getNumHouses(){
    return numHouses;
  }
  @Override
  public int getCurrentPlayer(){
    return playerToInt(currentPlayer);
  }
  @Override
  public int getScore(int playerNum) {
    int score = getStore(intToPlayer(playerNum)).getSeeds();
    for (int i = 0; i < numHouses; i ++){
      score += getHouse(intToPlayer(playerNum), i + 1).getSeeds();
    }
    return score;
  }
  @Override
  public int getSeedsInHouse(int playerNum, int houseNum){
    return getHouse(intToPlayer(playerNum), houseNum).getSeeds();
  }
  @Override
  public int getSeedsInStore(int playerNum){
    return getStore(intToPlayer(playerNum)).getSeeds();
  }
  @Override
  public boolean canSelectHouse(int houseNum){
    if (getHouse(currentPlayer, houseNum).getSeeds() != 0){
      return true;
    } else {
      return false;
    }
  }
  @Override
  public boolean gameEnded(){
    for (int i = 0; i < numHouses; i ++){
      if (getHouse(currentPlayer, i + 1).getSeeds() != 0){
        return false;
      }
    }
    return true;
  }
  @Override
  public void takeTurn(int houseNum) {
    if (!canSelectHouse(houseNum)){
      throw new IllegalArgumentException("Invalid house number - Player cannot select a house with no seeds in it");
    }
    House chosenHouse = getHouse(currentPlayer, houseNum);
    int seeds = chosenHouse.getSeeds();
    chosenHouse.setSeeds(0);
    Pit pit = chosenHouse;
    while (seeds > 0) {
      pit = nextPit(pit);
      if (pit.getPlayer() != currentPlayer && pit instanceof Store) {
        pit = nextPit(pit);
      }
      pit.setSeeds(pit.getSeeds() + 1);
      seeds--;
    }
    if (pit instanceof Store){
      return;
    }
    if (pit.getSeeds() == 1 && pit instanceof House
        && pit.getPlayer() == currentPlayer
        && (getOppositeHouse((House)pit).getSeeds() >= 1 || emptyCapture)) {
      capture(currentPlayer, (House)pit);
    }
    currentPlayer = getOtherPlayer(currentPlayer);
    return;
  }
  private House getHouse(Player player, int houseNum) {
    if (player == Player.PLAYER_1) {
      return (House) pits.get(houseNum - 1);
    } else {
      return (House) pits.get(houseNum + numHouses);
    }
  }
  private Store getStore(Player player){
    if (player == Player.PLAYER_1){
      return (Store) pits.get(numHouses);
    } else {
      return (Store) pits.get(numHouses * 2 + 1);
    }
  }
  private Player intToPlayer(int playerNum){
    if (!(playerNum == 1 || playerNum == 2)){
      throw new IllegalArgumentException("Invalid player number - must be 1 or 2");
    }
    if (playerNum == 1){
      return Player.PLAYER_1;
    } else {
      return Player.PLAYER_2;
    }
  }
  private int playerToInt(Player player){
    if (player == Player.PLAYER_1){
      return 1;
    } else {
      return 2;
    }
  }
  private void capture(Player player, House house){
    Store store = getStore(player);
    store.setSeeds(store.getSeeds() + 1);
    house.setSeeds(0);
    store.setSeeds(store.getSeeds() + getOppositeHouse(house).getSeeds());
    getOppositeHouse(house).setSeeds(0);
  }
  private Pit nextPit(Pit currentPit) {
    int index = pits.indexOf(currentPit);
    if (direction == Direction.ANTICLOCKWISE) {
      if (index + 1 == pits.size()) {
        return pits.get(0);
      } else {
        return pits.get(index + 1);
      }
    } else {
      if (index == 0){
        return pits.get(pits.size());
      } else {
        return pits.get(index - 1);
      }
    }
  }
  private House getOppositeHouse(House house) {
    return (House) pits.get(numHouses * 2 - pits.indexOf(house));
  }
  private Player getOtherPlayer(Player player) {
    if (player == Player.PLAYER_1) {
      return Player.PLAYER_2;
    } else {
      return Player.PLAYER_1;
    }
  }
}
