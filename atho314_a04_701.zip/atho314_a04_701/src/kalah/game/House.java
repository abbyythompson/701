package kalah.game;

import java.util.LinkedList;

/**
 * Object of a pit on the board.
 */
public class House extends Pit {

    /**
     * Add initial stones to the pit for start of the game.
     * @param initStones how many stones put initially in the pit.
     */
    public House(int initStones) {
        super();

        for (int i = 0; i < initStones; i++) {
            Stone stone = new Stone();
            this.stones.add(stone);
        }
    }

    /**
     * Removes all stones from a pit and puts it in a stack.
     * @return all the current stones in a LinkedList.
     */
    LinkedList<Stone> removeAllStones() {
        LinkedList<Stone> takenStones = new LinkedList<>(stones);
        stones.clear();
        return takenStones;
    }

    /**
     * Will see if there there are no stones left in the pit.
     * @return True if there are no stones. False if >0 stones.
     */
    Boolean isEmpty() {
        return stones.isEmpty();
    }
}
