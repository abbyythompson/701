package kalah.game;

import kalah.player.Player;
import kalah.status.Status;

/**
 * Interface for the Game logic class.
 */
public interface IGame {
    void setStatus(Status statusSet);
    void start();
    void move(Integer pitIndex);
    boolean gameFinished();
    Player getWinner();
    void finishMove();
    void getEndScore(Player player);
}
