package kalah.wrapper;
public interface ISetter<T> {
	public void set(T t);
}
