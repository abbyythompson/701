package kalah;

import kalah.game.*;
import kalah.status.*;
import kalah.printer.*;

import com.qualitascorpus.testsupport.IO;
import com.qualitascorpus.testsupport.MockIO;

/**
 * This class is the implementation and printing of the game logic.
 */
public class Kalah {
    private BoardPrinter boardPrinter;
    private Game game;
    private Boolean quit = false;

    public static void main(String[] args) {
        new Kalah().play(new MockIO());
    }

    /**
     * Starting the game with the other classes through io.
     * @param io printer.
     */
    public void play(IO io) {

        game = new Game();
        game.start();
        boardPrinter = new BoardPrinter(io, game);

        while(Status.FINISHED != game.getStatus()) {

            boardPrinter.printBoard();

            String turn = "";
            switch (game.getStatus()) {
                case PLAYER1_TURN:
                    turn = Constants.P1_TURN;
                    break;
                case PLAYER2_TURN:
                    turn = Constants.P2_TURN;
                    break;
            }

            int inputMove = io.readInteger(turn, 1, 6, -1, "q");

            if (inputMove > 0) {
                game.move((inputMove - 1));

                if(game.getMove() == Move.ILLEGAL){
                    io.println(Constants.EMPTY_HOUSE);
                }

                if(game.gameFinished()) {
                    game.setStatus(Status.FINISHED);
                    boardPrinter.printBoard();
                }
            } else { // the player has quit
                game.setStatus(Status.FINISHED);
                quit = true;
            }
        }

        boardPrinter.printEndGame();
        game.finishMove();

        //if the player didn't quit. Print the winner.
        if (!quit){
            boardPrinter.printWinner();
        }
    }
}
