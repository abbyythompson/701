package kalah.playeraction;
public interface IAction<T> {
	public void Do(T arg);
}
