package kalah;

import java.util.ArrayList;

/**
 * Player Object that has each player's pit and house objects.
 */
public class Player {

    private final String name;
    private final ArrayList<Pit> pits;
    private final House house;

    /**
     * Constructor with number of pits for a player and the number of stones for each pit.
     * @param name The player's name.
     * @param initStones The number stones for each pit.
     * @param initPits The number of pits for the player.
     */
    public Player(String name, int initStones, Integer initPits) {
        this.name = name;
        pits = new ArrayList<>();
        house = new House();

        for (int i = 0; i < initPits; i++) {
            Pit pit = new Pit(initStones);
            pits.add(pit);
        }
    }

    /**
     * Getter for name of player.
     * @return the name of the player.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the player's pit that is asked for by it's index.
     * @param pitIndex index of the pit. 0..initIndex-1.
     * @return the requested pit or null if out of range.
     */
    public Pit getPit(Integer pitIndex) {
        if (pitIndex < 0 || pitIndex >= pits.size()) {
            return null;
        }
        return pits.get(pitIndex);
    }

    /**
     * Getter for player's house.
     * @return the player's house.
     */
    public House getHouse() {
        return house;
    }

    /**
     * If the player has any stones left.
     * @return true is player has stones. False if not.
     */
    protected Boolean hasStones() {
        for (Pit pit : pits) {
            if (pit.size() > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Getter of pits in indexed array.
     * @return array of pits.
     */
    public ArrayList<Pit> getPits() {
        return pits;
    }
}
