package kalah;
public class SownResult {
	public static final int PLAYER_HOUSE = 0;
	public static final int PLAYER_STORAGE = 1;
	public static final int OPPONENT_HOUSE = 2;
	int houseType;
	int lastSown;
	public SownResult(int typeOfHouse, int currentIndex) {
		this.houseType = typeOfHouse;
		this.lastSown = currentIndex;
	}
	public int getHouseType() {
		return houseType;
	}
	public int getLastSown() {
		return lastSown;
	}
}
