package kalah;
import com.qualitascorpus.testsupport.IO;
public class HumanPlayer extends Player {
	public HumanPlayer(String name) {
		super(name);
	}
	@Override
	public int getChoice(IO io) {
		String input = io.readFromKeyboard("Player " + name + "'s turn - Specify house number or 'q' to quit: ");
		if (input.equals("q")) {
			return -1;
		} else {
			int value = Integer.parseInt(input);
			return value;
		}
	}
}
