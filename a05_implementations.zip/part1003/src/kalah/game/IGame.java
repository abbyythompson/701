package kalah.game;
public interface IGame {
  int getNumHouses();
  int getCurrentPlayer();
  int getScore(int playerNum);
  int getSeedsInHouse(int playerNum, int houseHum);
  int getSeedsInStore(int playerNum);
  boolean canSelectHouse(int houseNum);
  boolean gameEnded();
  void takeTurn(int houseNum);
}
