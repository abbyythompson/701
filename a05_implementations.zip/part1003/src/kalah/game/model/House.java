package kalah.game.model;
public class House implements Pit {
  private Player player;
  private int numSeeds;
  public House(Player player, int numSeeds) {
    this.player = player;
    this.numSeeds = numSeeds;
  }
  @Override
  public Player getPlayer() {
    return player;
  }
  @Override
  public int getSeeds() {
    return numSeeds;
  }
  @Override
  public void setSeeds(int numSeeds) {
    this.numSeeds = numSeeds;
  }
}