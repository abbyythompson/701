package kalah;

import com.qualitascorpus.testsupport.IO;
import com.qualitascorpus.testsupport.MockIO;

/**
 * This class is the implementation and printing of the game logic.
 */
public class Kalah {
    private Player p1;
    private Player p2;
    private Game game;
    private Boolean quit = false;

    public static void main(String[] args) {
        new Kalah().play(new MockIO());
    }

    /**
     * Starting the game with the other classes through io.
     * @param io printer.
     */
    public void play(IO io) {

        game = new Game();
        p1 = game.getPlayer1();
        p2 = game.getPlayer2();
        Player currentPlayer;

        game.start();

        while(Status.FINISHED != game.getStatus()) {

            currentPlayer = game.movingPlayer();
            printBoard(io);

            int inputMove = io.readInteger(
                    "Player " + currentPlayer.getName() + "'s turn - Specify house number or 'q' to quit: ",
                    1,
                    6,
                    -1,
                    "q");

            if (inputMove > 0) {
                game.move((inputMove - 1));

                if(game.getMove() == Move.ILLEGAL){
                    io.println("House is empty. Move again.");
                }

                if(game.gameFinished(currentPlayer)) {
                    game.setStatus(Status.FINISHED);
                    printBoard(io);
                }
            } else { // the player has quit
                game.setStatus(Status.FINISHED);
                quit = true;
            }
        }
        endGame(quit, io);
    }

    /**
     * Print the current state of the board.
     * @param io to print io.
     */
    private void printBoard(IO io){
        String line = "+----+-------+-------+-------+-------+-------+-------+----+";
        String midLine = "|    |-------+-------+-------+-------+-------+-------|    |";

        // Start of printing the board
        io.println(line);
        io.print("| P2 | ");

        for(int i = 6; i > 0; i--){
            printPits(io, p2, i);
        }

        printHouse(io, p1, true);
        io.println(midLine);
        io.print("| ");
        printHouse(io, p2, false);

        for(int i = 1; i < 7; i++){
            printPits(io, p1, i);
        }

        io.println("P1 |");
        io.println(line);
    }

    /**
     * Print the specific house for a player.
     * @param io printer.
     * @param player player to get their specific house.
     * @param newline whether it needs a new line or not.
     */
    private void printHouse(IO io, Player player, Boolean newline){
        if (player.getHouse().size() < 10) {
            io.print(" ");
        }
        if (newline) {
            io.println(player.getHouse().size() + " |");
        } else {
            io.print(player.getHouse().size() + " | ");

        }
    }

    /**
     * Print the specific pit for a player.
     * @param io printer.
     * @param player player to get their pits.
     * @param i the current iteration in the loop.
     */
    private void printPits(IO io, Player player, int i){
        if (9 < player.getPits().get(i-1).size()) {
            io.print(i + "[");
        } else {
            io.print(i + "[ ");
        }
        io.print(String.valueOf(player.getPits().get(i-1).size()));
        io.print("] | ");
    }

    /**
     * Print out the game over, last board and tally up the scores.
     * @param quit boolean to tell if the player quit or not.
     * @param io to print out the test io.
     */
    private void endGame (Boolean quit, IO io){
        io.println("Game over");
        printBoard(io);
        game.finishMove();

        //if the player didn't quit. Print the winner.
        if (!quit) {
            printWinner(io);
        }
    }

    /**
     * Print the score and who won/tied.
     * @param io to print out the test io.
     */
    private void printWinner(IO io) {
        Player winner = game.getWinner();

        io.println("\tplayer 1:" + p1.getHouse().size());
        io.println("\tplayer 2:" + p2.getHouse().size());

        if (winner != null){
            if (winner == p1) {
                io.println("Player 1 wins!");
            } else {
                io.println("Player 2 wins!");
            }
        } else {
            io.println("A tie!");
        }
    }
}
