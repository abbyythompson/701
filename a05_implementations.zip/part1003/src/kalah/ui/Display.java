package kalah.ui;
import com.qualitascorpus.testsupport.IO;
import kalah.game.IGame;
public class Display implements IDisplay{
  private IO io;
  private IGame game;
  public Display(IO io, IGame game){
    this.io = io;
    this.game = game;
  }
  private String pad(int number) {
    if (number > 9) {
      return "" + number;
    } else {
      return " " + number;
    }
  }
  @Override
  public int prompt() {
    return io.readInteger(getPrompt(), 1, game.getNumHouses(), -1, "q");
  }
  private String getPrompt() {
    if (game.getCurrentPlayer() == 1) {
      return Constants.PLAYER_1_PROMPT;
    } else {
      return Constants.PLAYER_2_PROMPT;
    }
  }
  @Override
  public void showBoard() {
    showRow1();
    showRow2();
    showRow3();
    showRow4();
    showRow1();
  }
  private void showRow1() {
    io.print("+----+");
    for (int i = 0; i < game.getNumHouses(); i++) {
      io.print("-------+");
    }
    io.println("----+");
  }
  private void showRow2() {
    io.print("| P2 |");
    for (int i = 0; i < game.getNumHouses(); i++) {
      io.print(pad(game.getNumHouses() - i) + "[" + pad(game.getSeedsInHouse(2, game.getNumHouses() - i)) + "] |");
    }
    io.println(" " + pad(game.getSeedsInStore(1)) + " |");
  }
  private void showRow3() {
    io.print("|    |");
    for (int i = 0; i < game.getNumHouses() - 1; i++) {
      io.print("-------+");
    }
    io.print("-------|");
    io.println("    |");
  }
  private void showRow4() {
    io.print("| " + pad(game.getSeedsInStore(2)) + " |");
    for (int i = 0; i < game.getNumHouses(); i++) {
      io.print(pad(i + 1) + "[" + pad(game.getSeedsInHouse(1, i + 1)) + "] |");
    }
    io.println(" P1 |");
  }
  @Override
  public void showEmpty() {
    io.println(Constants.HOUSE_IS_EMPTY);
    showBoard();
  }
  @Override
  public void showQuit() {
    io.println(Constants.GAME_OVER);
    showBoard();
  }
  @Override
  public void showScore() {
    int player1Score = game.getScore(1);
    int player2Score = game.getScore(2);
    io.println(Constants.GAME_OVER);
    this.showBoard();
    io.println("\t" + Constants.PLAYER_1_SCORE + ":" + player1Score);
    io.println("\t" + Constants.PLAYER_2_SCORE + ":" + player2Score);
    if (player1Score > player2Score) {
      io.println(Constants.PLAYER_1_WINS);
    } else if (player1Score < player2Score) {
      io.println(Constants.PLAYER_2_WINS);
    } else {
      io.println(Constants.TIE);
    }
  }
}
