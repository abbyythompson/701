package kalah.wrapper;
public interface IGetter<T> {
	public T get();
}

